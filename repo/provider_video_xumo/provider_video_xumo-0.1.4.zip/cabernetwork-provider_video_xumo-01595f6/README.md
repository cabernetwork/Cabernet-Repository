# provider_video_xumo
Provides an interface to XUMO

Just take the release zip file and drop the provider_video_xumo folder into the plugins_ext folder. This plugin will normally auto-enable, but most plugins will enable using the following update to the config.ini file
<pre>
[xumo_default]
label = XUMO Instance
</pre>
