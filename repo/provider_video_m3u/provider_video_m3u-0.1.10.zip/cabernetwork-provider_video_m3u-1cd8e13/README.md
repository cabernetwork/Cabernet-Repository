# provider_video_m3u
Provides an interface to the M3U and XMLTV.XML URLs

Just take the release zip file and drop the provider_video_m3u folder into the plugins_ext folder. This plugin will normally auto-enable, but most plugins will enable using the following update to the config.ini file
<pre>
[m3u_default]
label = M3U Instance
</pre>
