# provider_epg_tvguide
Provides an interface to the TVGuide

Just take the release zip file and drop the provider_epg_tvguide folder into the plugins_ext folder. This plugin will normally auto-enable, but most plugins will enable using the following update to the config.ini file
<pre>
[tvguide_default]
label = TVGuide Instance
</pre>
