# provider_video_plutotv
Provides an interface to PlutoTV

Just take the release zip file and drop the provider_video_plutotv folder into the plugins_ext folder. This plugin will normally auto-enable, but most plugins will enable using the following update to the config.ini file
<pre>
[plutotv_default]
label = PlutoTV Instance
</pre>
