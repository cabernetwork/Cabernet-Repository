# pylama:ignore=E203,E221
"""
MIT License

Copyright (C) 2023 ROCKY4546
https://github.com/rocky4546

This file is part of Cabernet

Permission is hereby granted, free of charge, to any person obtaining a copy of this software
and associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.
"""


daddylive_base = 'gfpMXf5BjIUoyx3oj8lQjG=='
daddylive_channels = '56nPlIC6gxdFyZrEXISGgfW='
daddylive_stream = 'XRpItbdPjRlMXZr3yqCT1qSGgfW='
daddylive_dl22e = b'5c9I5KnCl6XJmbdYkNp7tZz+gb/OyxCFyRaLX8lMzstR0f7Bnhicp9rxpM3iqoP54hSuhddqhCprr7zkbr+OjG=='
