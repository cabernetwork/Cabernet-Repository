# provider_video_daddylive
Provides an interface to DaddyLiveHD

Just take the release zip file and drop the provider_video_daddylive folder into the plugins_ext folder. This plugin will normally auto-enable, but most plugins will enable using the following update to the config.ini file
<pre>
[daddylive_default]
label = DaddyLive Instance
</pre>
